export type ApiResponse<T = any> = {
    message: string,
    result: T,
}
