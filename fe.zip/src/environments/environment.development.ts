export const environment = {
  production: false,
  // add your dev environment variables here
  firebase: {
        apiKey: "AIzaSyBmkkO6Cg2iL6q2h6nOfPctB5UMIvS3OA4",
        authDomain: "jkswanand.firebaseapp.com",
        projectId: "jkswanand",
        storageBucket: "jkswanand.firebasestorage.app",
        messagingSenderId: "483564995152",
        appId: "1:483564995152:web:04e78d7d06843758948755",
        measurementId: "G-D00Q3V3D9H"
    }
};
